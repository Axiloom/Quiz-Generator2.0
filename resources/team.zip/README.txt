README

Course: cs400

Semester: Spring 2019

Project name: Quiz Generator

Team Members:

1. Josh Liberko, lecture: 001, jliberko@wisc.edu, x-team 6
2. John Bednarczyk, lecture: 001, jbednarczyk@wisc.edu, x-team 6
3. Joe Lessner, lecture: 001, jalessner@wisc.edu, x-team 6
4. Shefali Mukerji, lecture: 001, mukerji2@wisc.edu, x-team 6
5. Mitch Sutrick, lecture: 001, sutrick@wisc.edu, x-team 41

Notes or comments to the grader:
NONE
